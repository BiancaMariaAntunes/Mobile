import Home from "./home";


export default function App() {
  return (
      <Home/>
  );
}

